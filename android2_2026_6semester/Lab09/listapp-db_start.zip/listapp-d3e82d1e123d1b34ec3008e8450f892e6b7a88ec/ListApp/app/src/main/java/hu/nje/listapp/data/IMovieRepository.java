package hu.nje.listapp.data;

import java.util.List;

import hu.nje.listapp.domain.Movie;

public interface IMovieRepository {
    List<Movie> getAll();
}
