package hu.nje.listapp.ui.movielist;

import java.util.List;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import hu.nje.listapp.MainActivity;
import hu.nje.listapp.R;
import hu.nje.listapp.data.IMovieRepository;
import hu.nje.listapp.data.MockMovieRepository;
import hu.nje.listapp.domain.Movie;

public class MovieListFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie_list, container, false);

        IMovieRepository movieRepository = new MockMovieRepository();
        List<Movie> movieList = movieRepository.getAll();

        RecyclerView recyclerView = view.findViewById(R.id. movieRecyclerView);

        NavController navController = ((MainActivity)getActivity()).getNavController();
        MovieListAdapter adapter = new MovieListAdapter(movieList, navController);
        RecyclerView.LayoutManager layoutManager =
                new LinearLayoutManager(getActivity()
                        .getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);


        return view;
    }
}