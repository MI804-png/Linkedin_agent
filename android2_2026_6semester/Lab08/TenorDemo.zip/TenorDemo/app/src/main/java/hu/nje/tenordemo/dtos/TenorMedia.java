package hu.nje.tenordemo.dtos;

public class TenorMedia {
    public TenorMediaItem gif;
}
