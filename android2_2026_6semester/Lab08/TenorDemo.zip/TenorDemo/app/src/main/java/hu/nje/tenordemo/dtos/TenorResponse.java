package hu.nje.tenordemo.dtos;

import java.util.List;

public class TenorResponse {
    public List<TenorResult> results;
}
