package hu.nje.tenordemo;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;

import hu.nje.tenordemo.dtos.TenorResponse;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.Call;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private EditText searchEditText;
    private Button searchButton;
    private Button randomButton;
    private Button trendingButton;
    private TextView resultTextView;
    private ImageView resultImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);
        randomButton = findViewById(R.id.randomButton);
        trendingButton = findViewById(R.id.trendingButton);
        resultTextView = findViewById(R.id.resultTextView);
        resultImageView = findViewById(R.id.resultImageView);
    }

    @Override
    protected void onStart() {
        super.onStart();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.tenor.com/v1/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        TenorClient client = retrofit.create(TenorClient.class);

        Call<TenorResponse> call =
                client.searchByTag("LIVDSRZULELA", "patrick+star");

        call.enqueue(new Callback<TenorResponse>() {
            @Override
            public void onResponse(Call<TenorResponse> call, Response<TenorResponse> response) {
                if(response.isSuccessful()) {
                    String url = response.body()
                            .results.get(0)
                            .mediaList.get(0)
                            .gif.url;

                    resultTextView.setText(url);

                    Glide.with(getApplicationContext())
                            .load(url)
                            .into(resultImageView);
                }
            }

            @Override
            public void onFailure(Call<TenorResponse> call, Throwable t) {
                Log.e("MainActivity", t.getMessage());
            }
        });
    }
}