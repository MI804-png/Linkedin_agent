package hu.nje.tenordemo.dtos;

public class TenorMediaItem {
    public String url;
    public String preview;
    public long size;
}
