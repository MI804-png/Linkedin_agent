package hu.nje.tenordemo;

import hu.nje.tenordemo.dtos.TenorResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface TenorClient {

    // https://api.tenor.com/v1/random?key=LIVDSRZULELA
    @GET("random")
    Call<TenorResponse> getRandom(@Query("key") String key);

    @GET("trending")
    Call<TenorResponse> getTrending(@Query("key") String key);

    // https://api.tenor.com/v1/search?key=aaa&tag=patrick+star
    @GET("search")
    Call<TenorResponse> searchByTag(@Query("key") String key,
                                    @Query("tag") String tag);
}
