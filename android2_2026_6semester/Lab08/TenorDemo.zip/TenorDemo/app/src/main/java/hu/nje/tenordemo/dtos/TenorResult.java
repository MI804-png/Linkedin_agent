package hu.nje.tenordemo.dtos;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TenorResult {
    public String id;
    public boolean hasaudio;

    @SerializedName("content_description")
    public String description;

    @SerializedName("url")
    public String pageUrl;

    @SerializedName("media")
    public List<TenorMedia> mediaList;
}
