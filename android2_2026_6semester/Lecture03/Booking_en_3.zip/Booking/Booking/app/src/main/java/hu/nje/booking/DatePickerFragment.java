package hu.nje.booking;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.time.LocalDate;

public class DatePickerFragment extends DialogFragment {

    private static final String ARG_YEAR = "year";
    private static final String ARG_MONTH = "month";
    private static final String ARG_DAY = "day";

    private int year;
    private int month;
    private int day;

    private DatePickerFragment() { }

    public static DatePickerFragment newIntance(
            int year, int month, int day) {
        DatePickerFragment fragment =
                new DatePickerFragment();

        Bundle args = new Bundle();
        args.putInt(ARG_YEAR, year);
        args.putInt(ARG_MONTH, month);
        args.putInt(ARG_DAY, day);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle arg = getArguments();
        if(arg != null ){
            year = arg.getInt(ARG_YEAR);
            month = arg.getInt(ARG_MONTH);
            day = arg.getInt(ARG_DAY);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        /*LocalDate now = LocalDate.now();
        int year = now.getYear();
        int month = now.getMonthValue(); //1-12
        int day = now.getDayOfMonth();

        // 0-11
        month--;*/

        DatePickerDialog dialog = new DatePickerDialog(
            getContext(),
                (MainActivity)getActivity(),
                year, month, day
        );


        return dialog;
    }
}
