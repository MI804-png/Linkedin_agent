package hu.nje.booking;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class MainActivity
        extends AppCompatActivity
        implements DatePickerDialog.OnDateSetListener
{

    private EditText destinationEditText;
    private Button checkInButton;
    private Button checkOutButton;
    private Spinner adultsSpinner;
    private Spinner childrenSpinner;
    private Spinner roomsSpinner;
    private CheckBox businessCheckBox;
    private Button searchButton;

    private boolean isCheckInSelected = false;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        destinationEditText = findViewById(R.id.destinationEditText);
        checkInButton = findViewById(R.id.checkInButton);
        checkOutButton = findViewById(R.id.checkOutButton);
        adultsSpinner = findViewById(R.id.adultsSpinner);
        childrenSpinner = findViewById(R.id.childrenSpinner);
        roomsSpinner = findViewById(R.id.roomsSpinner);
        businessCheckBox = findViewById(R.id.businessCheckBox);
        searchButton = findViewById(R.id.searchButton);

        initSpinner(R.array.number_of_adults, adultsSpinner);
        initSpinner(R.array.number_of_children, childrenSpinner);
        initSpinner(R.array.number_of_rooms, roomsSpinner);

        checkInButton.setOnClickListener(v -> {
            isCheckInSelected = true;
            LocalDate now = LocalDate.now();
            int year = now.getYear();
            int month = now.getMonthValue(); //1-12
            int day = now.getDayOfMonth();

            // 0-11
            month--;

            DatePickerFragment fragment =
                    DatePickerFragment.newIntance(year, month, day);
            fragment.show(getSupportFragmentManager(), "checkIn");
        });

        checkOutButton.setOnClickListener(v -> {

            if(checkInDate == null) {
                Toast.makeText(getApplicationContext(),
                        "Select the check in date first!",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            isCheckInSelected = false;

            LocalDate minCheckOutDate =
                    checkInDate.plusDays(1);
            int year = minCheckOutDate.getYear();
            int month = minCheckOutDate.getMonthValue() - 1;
            int day = minCheckOutDate.getDayOfMonth();

            DatePickerFragment fragment =
                    DatePickerFragment.newIntance(year, month, day);
            fragment.show(getSupportFragmentManager(), "checkOut");
        });

        searchButton.setOnClickListener(v -> {

            String dest = destinationEditText.getText().toString();

            Toast.makeText(getApplicationContext(),
                    "Destination: " + dest,
                    Toast.LENGTH_SHORT).show();
        });
    }


    private void initSpinner(int resId, Spinner spinner) {
        ArrayAdapter<CharSequence> adapter =
                ArrayAdapter.createFromResource(this,
                resId,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinner.setAdapter(adapter);
    }

    @Override
    public void onDateSet(DatePicker datePicker,
                          int year, int month, int day) {
        month++;
        LocalDate date =
                LocalDate.of(year, month, day);
        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formatted = date.format(formatter);

        if(isCheckInSelected) {
            checkInDate = date;
            checkInButton.setText(formatted);
        } else {
            checkOutDate = date;
            checkOutButton.setText(formatted);
        }

    }
}