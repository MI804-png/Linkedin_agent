package hu.nje.recyclerviewdemo.data.repositories;

import java.util.List;

import hu.nje.recyclerviewdemo.domain.Movie;

public interface IMovieRepository {
    List<Movie> getAll();
}
