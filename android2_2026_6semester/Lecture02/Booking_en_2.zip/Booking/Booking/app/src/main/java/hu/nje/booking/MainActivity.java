package hu.nje.booking;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText destinationEditText;
    private Button checkInButton;
    private Button checkOutButton;
    private Spinner adultsSpinner;
    private Spinner childrenSpinner;
    private Spinner roomsSpinner;
    private CheckBox businessCheckBox;
    private Button searchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        destinationEditText = findViewById(R.id.destinationEditText);
        checkInButton = findViewById(R.id.checkInButton);
        checkOutButton = findViewById(R.id.checkOutButton);
        adultsSpinner = findViewById(R.id.adultsSpinner);
        childrenSpinner = findViewById(R.id.childrenSpinner);
        roomsSpinner = findViewById(R.id.roomsSpinner);
        businessCheckBox = findViewById(R.id.businessCheckBox);
        searchButton = findViewById(R.id.searchButton);

        initSpinner(R.array.number_of_adults, adultsSpinner);
        initSpinner(R.array.number_of_children, childrenSpinner);
        initSpinner(R.array.number_of_rooms, roomsSpinner);

        searchButton.setOnClickListener(v -> {

            String dest = destinationEditText.getText().toString();

            Toast.makeText(getApplicationContext(),
                    "Destination: " + dest,
                    Toast.LENGTH_SHORT).show();
        });
    }


    private void initSpinner(int resId, Spinner spinner) {
        ArrayAdapter<CharSequence> adapter =
                ArrayAdapter.createFromResource(this,
                resId,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinner.setAdapter(adapter);
    }
}