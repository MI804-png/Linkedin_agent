package hu.nje.navigationdemo;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity {

    private NavController navController;
    private AppBarConfiguration appBarConfiguration;

    private String savedProfileName;

    public String getSavedProfileName() {
        return savedProfileName;
    }

    public void navigateToHome() {
        navController.navigate(R.id.homeFragment);
    }

    public void saveAndNavigateToHome(String profileName) {
        savedProfileName = profileName;
        navigateToHome();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar mainToolbar = findViewById(R.id.mainToolbar);
        setSupportActionBar(mainToolbar);

        setTitle("Nav app");

        // Setup navigation
        NavHostFragment navHostFragment =
                (NavHostFragment)
                getSupportFragmentManager()
                        .findFragmentById(R.id.navHostFragment);

        navController = navHostFragment.getNavController();

        // top level destinations setup
        appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.homeFragment,
                R.id.profileFragment,
                R.id.settingsFragment
        ).build();

        NavigationUI.setupActionBarWithNavController(this,
                navController,
                appBarConfiguration);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        /*if(item.getItemId() == R.id.homeFragment) {
            showMessage("Home is selected");
        } else if (item.getItemId() == R.id.profileFragment) {
            showMessage("Profile");
        } else if (item.getItemId() == R.id.settingsFragment) {
            showMessage("Settings");
        }
        return true;
        */

        return NavigationUI
                .onNavDestinationSelected(item, navController);
    }

    private void showMessage(String message) {
        Toast.makeText(this,
                message, Toast.LENGTH_SHORT).show();
    }
}