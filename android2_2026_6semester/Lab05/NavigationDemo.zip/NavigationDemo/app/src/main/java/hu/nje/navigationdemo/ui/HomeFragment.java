package hu.nje.navigationdemo.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import hu.nje.navigationdemo.MainActivity;
import hu.nje.navigationdemo.R;


public class HomeFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        TextView profileNameTextView =
                view.findViewById(R.id.profileNameTextView);
        String savedProfileName =
                ((MainActivity)getActivity()).getSavedProfileName();

        if(savedProfileName != null && !savedProfileName.isEmpty()) {
            profileNameTextView.setText(
                    "Welcome " + savedProfileName);
        }


        return view;
    }
}