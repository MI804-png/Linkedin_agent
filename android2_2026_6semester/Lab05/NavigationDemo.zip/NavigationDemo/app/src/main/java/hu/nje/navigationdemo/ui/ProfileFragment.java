package hu.nje.navigationdemo.ui;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import hu.nje.navigationdemo.MainActivity;
import hu.nje.navigationdemo.R;

public class ProfileFragment extends Fragment {

    private final int CAMERA_REQUEST_CODE = 10000;
    private ImageView profileImageView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        profileImageView =
                view.findViewById(R.id.profileImageView);
        EditText profileNameEditText =
                view.findViewById(R.id.profileNameEditText);
        Button cancelButton =
                view.findViewById(R.id.cancelButton);
        Button saveButton =
                view.findViewById(R.id.saveButton);

        MainActivity mainActivity = (MainActivity) getActivity();

        profileNameEditText.setText(mainActivity.getSavedProfileName());

        cancelButton.setOnClickListener(v -> {
            mainActivity.navigateToHome();
        });

        saveButton.setOnClickListener(v -> {
            String profileName = profileNameEditText.getText().toString();
            mainActivity.saveAndNavigateToHome(profileName);
        });

        profileImageView.setOnClickListener(v -> {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 @Nullable Intent data) {
        if(requestCode == CAMERA_REQUEST_CODE &&
                resultCode == RESULT_OK)   {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            profileImageView.setImageBitmap(photo);
        }
    }
}