package hu.nje.listapp;

import android.content.Context;

import androidx.room.Room;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


import static org.junit.Assert.*;

import hu.nje.listapp.data.MovieDatabase;
import hu.nje.listapp.data.entities.Movie;

@RunWith(AndroidJUnit4.class)
public class DatabaseTest {
    private MovieDatabase db;

    @Before
    public void createDb() {
        Context context = ApplicationProvider.getApplicationContext();
        db = Room.inMemoryDatabaseBuilder(context, MovieDatabase.class).build();
    }

    @After
    public void closeDb() {
        db.close();
    }

    @Test
    public void testInsertAndGetMovie() {
        // Új film létrehozása
        db.movieDao().insertMovie(new Movie(1, "Dune: Part Two", "Sci-fi", 2024));

        // Összes film lekérdezése
        assertEquals(1, db.movieDao().getAllMovies().size());

        // Az első film lekérdezése
        Movie firstMovie = db.movieDao().getAllMovies().get(0);
        assertEquals("Dune: Part Two", firstMovie.getTitle());
        assertEquals(2024, firstMovie.getYear());

        // Azonosító alapján lekérdezés
        Movie retrievedMovie = db.movieDao().getMovieById(firstMovie.getId());
        assertNotNull(retrievedMovie);
        assertEquals("Dune: Part Two", retrievedMovie.getTitle());
    }
}
