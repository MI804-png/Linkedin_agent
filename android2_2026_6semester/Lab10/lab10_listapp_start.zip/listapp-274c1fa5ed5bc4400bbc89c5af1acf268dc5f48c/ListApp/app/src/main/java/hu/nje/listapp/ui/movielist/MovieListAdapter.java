package hu.nje.listapp.ui.movielist;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import hu.nje.listapp.R;
import hu.nje.listapp.domain.Movie;
import hu.nje.listapp.ui.moviedetails.MovieDetailsArgs;

public class MovieListAdapter extends RecyclerView.Adapter<MovieListAdapter.MovieHolder> {

    private List<Movie> moviesList;
    private NavController navController;

    public MovieListAdapter(List<Movie> moviesList, NavController navController) {
        this.moviesList = moviesList;
        this.navController = navController;
    }

    @Override
    public MovieHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.movie_list_row, parent, false);

        return new MovieHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MovieHolder holder, int position) {
        Movie movie = moviesList.get(position);
        holder.titleTextView.setText(movie.getTitle());
        holder.genreTextView.setText(movie.getGenre());
        String year = Integer.toString(movie.getYear());
        holder.yearTextView.setText(year);

        holder.itemView.setOnClickListener(v -> {

            MovieDetailsArgs args = new MovieDetailsArgs(movie.getTitle(), movie.getGenre(), movie.getYear());
            Bundle bundle = new Bundle();
            bundle.putParcelable("MOVIE_DETAILS", args);
            navController.navigate(R.id.action_movieListFragment_to_movieDetailsFragment, bundle);
        });
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }

    public class MovieHolder extends RecyclerView.ViewHolder {
        public TextView titleTextView;
        public TextView genreTextView;
        public TextView yearTextView;

        public MovieHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            genreTextView = itemView.findViewById(R.id.genreTextView);
            yearTextView =  itemView.findViewById(R.id.yearTextView);
        }
    }
}

