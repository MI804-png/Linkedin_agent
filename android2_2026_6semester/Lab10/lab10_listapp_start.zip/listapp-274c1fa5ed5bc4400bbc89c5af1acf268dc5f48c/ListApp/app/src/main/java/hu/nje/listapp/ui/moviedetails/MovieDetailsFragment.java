package hu.nje.listapp.ui.moviedetails;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import hu.nje.listapp.R;

public class MovieDetailsFragment extends Fragment {

    private MovieDetailsArgs args;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            args = getArguments().getParcelable("MOVIE_DETAILS");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie_details, container, false);

        TextView movieTitleTextView = view.findViewById(R.id.movieTitleTextView);
        movieTitleTextView.setText(args.getTitle());

        return view;
    }
}