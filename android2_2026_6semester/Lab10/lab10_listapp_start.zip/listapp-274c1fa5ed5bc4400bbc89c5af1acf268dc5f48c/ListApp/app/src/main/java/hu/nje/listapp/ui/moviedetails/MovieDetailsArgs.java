package hu.nje.listapp.ui.moviedetails;

import android.os.Parcel;
import android.os.Parcelable;

public class MovieDetailsArgs implements Parcelable {
    private String title;
    private String genre;
    private int year;

    public MovieDetailsArgs(String title, String genre, int year) {
        this.title = title;
        this.genre = genre;
        this.year = year;
    }

    protected MovieDetailsArgs(Parcel in) {
        title = in.readString();
        genre = in.readString();
        year = in.readInt();
    }

    public static final Creator<MovieDetailsArgs> CREATOR = new Creator<MovieDetailsArgs>() {
        @Override
        public MovieDetailsArgs createFromParcel(Parcel in) {
            return new MovieDetailsArgs(in);
        }

        @Override
        public MovieDetailsArgs[] newArray(int size) {
            return new MovieDetailsArgs[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public int getYear() {
        return year;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(genre);
        dest.writeInt(year);
    }
}
