package hu.nje.listapp.data.repositories;

import java.util.ArrayList;
import java.util.List;

import hu.nje.listapp.data.MovieDatabase;

public class MovieDbRepository implements IMovieRepository {
    private final MovieDatabase database;

    public MovieDbRepository(MovieDatabase database) {
        this.database = database;
    }

    @Override
    public List<hu.nje.listapp.domain.Movie> getAll() {
        List<hu.nje.listapp.data.entities.Movie> entities = database.movieDao().getAllMovies();
        List<hu.nje.listapp.domain.Movie> movies = MapEntityToDomain(entities);
        return movies;
    }

    private List<hu.nje.listapp.domain.Movie> MapEntityToDomain(List<hu.nje.listapp.data.entities.Movie> entities){
        List<hu.nje.listapp.domain.Movie> movies = new ArrayList<>();

        for (hu.nje.listapp.data.entities.Movie entity : entities) {
            movies.add(new hu.nje.listapp.domain.Movie(entity.getTitle(), entity.getGenre(), entity.getYear()));
        }

        return movies;
    }
}
